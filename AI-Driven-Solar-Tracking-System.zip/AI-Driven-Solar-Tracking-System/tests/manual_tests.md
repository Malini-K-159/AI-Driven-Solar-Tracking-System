# Manual test cases (not yet executed)

| ID | Test | Expected behavior |
|---|---|---|
| T01 | Both LDRs have similar readings (difference within ±40) | No normal tracking step |
| T02 | Left reading exceeds right by more than 40 | Servo command decreases by 2°, down to 0° minimum |
| T03 | Right reading exceeds left by more than 40 | Servo command increases by 2°, up to 180° maximum |
| T04 | Repeated left/right imbalance at end stop | Angle remains within 0–180° |
| T05 | No threshold-exceeding difference for more than 60 s | One-degree fallback step, then timestamp reset |
| T06 | Open Serial Monitor at 9600 baud | Both readings and angle print |
| T07 | Mechanically move light source across sensors | Confirm direction; reverse servo commands if necessary |
| T08 | Disconnect one LDR temporarily with power off | Verify safe behavior before any unattended use |

Record actual measurements and pass/fail outcomes after testing hardware.
