# Architecture

```
Left LDR divider (A0) ----\
                           > Arduino UNO (ATmega328P) --> D9 servo signal --> Movable panel
Right LDR divider (A1) ---/
                            |
                            +--> USB serial diagnostics (9600 baud)
```

## Control flow
1. Read A0 and A1 (0–1023).
2. Compute `difference = left - right`.
3. If the difference exceeds ±40, step the servo by 2 degrees in the configured direction, clamped to 0–180 degrees.
4. Update a Q-like scalar for the chosen direction (currently diagnostic only, not used for action selection).
5. If 60 seconds pass without a threshold-exceeding reading, apply a one-degree fallback movement.
6. Print sensor readings and servo angle.

## Proposed future work
- Define discrete states, actions, rewards based on actual improvement, and action selection for genuine Q-learning.
- Verify improvement by rereading sensors after movement and revert unsuccessful steps.
- Replace simplistic fallback with a tested hourly policy if required.
- Measure net power gained after actuator consumption against a fixed panel.
